/********************* (C) COPYRIGHT 2018 e-Design Co.,Ltd. ********************
 DS213_APP Calibrat.h                                            Author : bure
*******************************************************************************/
#ifndef __CALIBRAT_H
#define __CALIBRAT_H


void Correction(void);

#endif  

/*******************************  END OF FILE  ********************************/
